#include "rlg327.h"
#include "binheap.h"

void dijkstra_tunneling(dungeon_t *d);
void print_binheap(binheap_t *h);

