#include "rlg327.h"
#include "binheap.h"

void dijkstra_nontunneling(dungeon_t *d);
void print_binheap(binheap_t *h);

